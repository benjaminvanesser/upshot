// globals ------------------------

outlets = 3;

var width = 160;
var height = 160;

var size = 10;
var mod = .05;
var friction = .999;

var style = "oval";

// amplitude modifiers
var xmod = width*mod;
var ymod = width*mod;

// toggles
this.toggle = new Object();
toggle.collisions = 0;
toggle.bouncing = 1;
toggle.friction = 0;
toggle.wall = 0;
toggle.onesound = 0;

// freezing
this.freeze = new Object();
freeze.x  = 0;
freeze.y  = 0;
freeze.xy = 0;

// key
this.key = new Object();
key.t = 0; // t key

// mouse
this.mouse = new Object();
mouse.x = 0;
mouse.y = 0;
mouse.dx = 0;
mouse.dy = 0;
mouse.down = 0;
mouse.hit = 0;

// colour
var c_rgb = [0,159,245];
var m_rgb = [255,0,122];
var y_rgb = [255,246,0];
var k_rgb = [0,0,0];
var w_rgb = [255,255,255];
var g_rgb = [0,255,0];
var p_rgb = [255,0,255];

// agents
var max_agents = 6;
var live_agent = -1;
var agents = new Array(max_agents);


// initialise agents
create_agents();

// initialisation routine
function create_agents(){
	var x = 0;
	var y = 0;
	var left = 0;
	var top = 0;
	var right = 0;
	var bottom = 0;
	var rgb = null;
	var xspeed = 0;
	var yspeed = 0;
	var mass = 0;
	var t = 0;
	
	for(i = 0; i < agents.length ; i++){
		xspeed = Math.random()*2;
		yspeed = Math.random()*2;
		x = Math.floor(Math.random()*127);
		y = Math.floor(Math.random()*127);
		mass = Math.random();
		rgb = rgb_variation();
		agent[i] = new agent(x,y,left,top,right,bottom,rgb,xspeed,yspeed,mass,t);
		}
		// set specific colours
		if(max_agents >= 1) agent[0].rgb = c_rgb;
		if(max_agents >= 2) agent[1].rgb = m_rgb;
		if(max_agents >= 3) agent[2].rgb = y_rgb;
		if(max_agents >= 4) agent[3].rgb = w_rgb;
		if(max_agents >= 5) agent[4].rgb = g_rgb;
		if(max_agents >= 6) agent[5].rgb = p_rgb;		
	}

// agent constructor
function agent(x,y,left,top,right,bottom,rgb,xspeed,yspeed,mass,t){
	this.x = x;
	this.y = y;
	this.left = left;
	this.top = top;
	this.right = right;
	this.bottom = bottom;
	this.rgb = rgb;
	this.xspeed = xspeed;
	this.yspeed = yspeed;
	this.mass = mass;
	this.t = t;
	}
	
// colour variation
function cmyk_variation(){
	var rand = Math.floor(Math.random()*4) + 1;
	if(rand == 1) return c_rgb;
	else if(rand == 2) return m_rgb;
	else if(rand == 3) return y_rgb;
	else return k_rgb;
}

function rgb_variation(){
	var v_rgb;
	v_rgb = [ztor(255),ztor(255),ztor(255)];
	return v_rgb;
	}
	
function ztor(range){
	var rval = Math.floor(Math.random()*range);
	return rval;
	}

// mouse position relative to top left corner
function mouse_loc(x,y){
	if(x < 0) x = 0;
	if(x > width) x = width;
	if(y < 0) y = 0;
	if(y > height) y = height;
	mouse.x = x;
	mouse.y = y;
	}

function button_up(){
	mouse.down = 0;
	mouse.hit = 0;
	if(live_agent != -1){
		if(!freeze.xy){
			evalspeed();
		}
		else {
			agent[live_agent].xspeed = 0;
			agent[live_agent].yspeed = 0;
			}
		}
	// update live_agent drift before you deselect
	live_agent = -1;
	}

function button_down(){
	mouse.down = 1;
	mouse.dx = mouse.x;
	mouse.dy = mouse.y;
	eval_hit();
	if(mouse.hit && key.t) toggle_switch();
	}
	
// key modifiers
function key_down(x){
	if(x == 102) freeze.xy 	= 1; // f key
	if(x == 120) freeze.y 	= 1; // x key
	if(x == 121) freeze.x 	= 1; // y key
	if(x == 116) key.t 	= 1; // t key
	if(x == 109) key.t 	= 1; // m key
	}

function key_up(x){//ok
	if(x == 102) freeze.xy 	= 0; // f key
	if(x == 120) freeze.y 	= 0; // x key
	if(x == 121) freeze.x 	= 0; // y key	
	if(x == 116) key.t 	= 0; // t key
	if(x == 109) key.t 	= 0; // m key
	} 
	

// on click check for agent selection
// topmost agent has focus
function eval_hit(){
	for(i = 0; i < agents.length; i++){
		var hit_x = 0;
		var hit_y = 0;
		if(Math.abs(mouse.x - agent[i].x) <= size*2) hit_x = 1;
		if(Math.abs(mouse.y - agent[i].y) <= size*2) hit_y = 1;
		if(hit_x && hit_y) live_agent = i;
		}
	if(live_agent != -1) mouse.hit = 1;
	}

// update speed/direction on drag-release
function evalspeed(){
	// if x key is down freeze x axis movement on mouse up
	if(freeze.x) agent[live_agent].xspeed = 0;
	else {
		agent[live_agent].xspeed = (mouse.dx - mouse.x)*mod;
		}
	// if y key is down freeze y axis movement on mouseup	
	if(freeze.y) agent[live_agent].yspeed = 0;
	else {
		agent[live_agent].yspeed = (mouse.dy - mouse.y)*mod;
		}
	}
	
// trigger on metro input
function bang(){
	if(mouse.down && mouse.hit){
		drag_agent(mouse.x,mouse.y);
		}
	update_loc();
	draw();
	}

	
// update location of selected agent
function drag_agent(x,y){
	agent[live_agent].x = x;
	agent[live_agent].y = y;
	agent_points(live_agent);
	}
	
// update agent registration points
function agent_points(n){
	// coords left,top,right,bottom
	agent[n].left = ftoi(agent[n].x) - size;
	agent[n].top = ftoi(agent[n].y) - size;
	agent[n].right = ftoi(agent[n].x) + size;
	agent[n].bottom = ftoi(agent[n].y) + size;	
	}	

// evaluate agent destinations and collisions
function update_loc(){
	// now update agents
	for(i = 0; i < agents.length; i++){
			if(i != live_agent){
			// collision detection
			if(toggle.collisions){
				collision(i);
				}
			// bounce detection
			bounce(i);
			if(toggle.bouncing){
				// use for muting walls
				}
			// friction detection
			if(toggle.friction){
				// apply friction to horizontal plane
				agent[i].xspeed *= friction;
				// apply friction to vertical plane
				agent[i].yspeed *= friction;							 
				}
			// move agent
			agent[i].x += agent[i].xspeed;
			agent[i].y += agent[i].yspeed;				
			// finally update the agent corners
			agent_points(i);
			}
		}
	}		
	
// lcd render routine
function draw(){
		// clear the display
		outlet(1,"bang");
		outlet(0,"brgb",k_rgb);
		// iterate thru agents
		for(i = 0; i < agents.length; i++){
		var frgb = agent[i].rgb;
		var block = "frame"+style;
		// check t state	
		if(agent[i].t) {
			frgb = k_rgb;
			block = "paint"+style;
			}		
		// blocks
		outlet(0,block,
			  agent[i].left,agent[i].top,agent[i].right,agent[i].bottom,agent[i].rgb);
		// write number
		outlet(0,"frgb",frgb);
		outlet(0,"moveto",ftoi(agent[i].x-2),ftoi(agent[i].y+3));
		outlet(0,"write",i);
		// control data - format: route, agent, xloc, yloc, x, y, xspeed, yspeed;
		outlet(2,"location",i,ftoi(agent[i].x)/width,(height-ftoi(agent[i].y))/height,
					ftoi(agent[i].x),ftoi(agent[i].y),agent[i].xspeed/xmod,agent[i].yspeed/ymod);
		}
	}
	
function collision(n){
	// check for collisions with other agents
	for(j = 0; j < agents.length; j++){
		if(j != n){
			var hit_x = 0;
			var hit_y = 0;
			var hit_left = 1;
			var hit_top = 1;
			// positions
			var dx = ftoi(agent[n].x + agent[n].xspeed) - ftoi(agent[j].x + agent[j].xspeed);
			var dy = ftoi(agent[n].y + agent[n].yspeed) - ftoi(agent[j].y + agent[j].yspeed);
			// absolute positions
			var adx = Math.abs(dx);
			var ady = Math.abs(dy);
			//absolute speeds
			var xs = Math.abs(agent[n].xspeed)/xmod;
			var ys = Math.abs(agent[n].yspeed)/ymod;
			// positions in range 0. to 1.
			var xloc = ftoi(agent[n].x)/width;
			var yloc = ftoi((height-agent[n].y))/height;
			// positions in midi
			var x = ftoi(agent[n].x);
			var y = ftoi((height-agent[n].y));
			// check overlap
			if(adx <= (size*2)+1 ) hit_x = 1;
			if(ady <= (size*2)+1 ) hit_y = 1;
			// now test combinations
			// hit output takes format: route,type,id,face,speed,xloc,yloc,x,y
			if(hit_x && hit_y){
				if(dx > 0) hit_left = 0;// hit right
				if(dy > 0) hit_top = 0; // hit bottom
				if(adx > ady){
					// the horizontal difference is greater than the vertical difference
					// now output collision data
						if(hit_left){
						//outlet(2,"impact left");
						if(!agent[n].t) outlet(2,"hit","agent",n,1,xs,xloc,yloc,x,y);
						agent[n].xspeed = 0 - agent[n].xspeed;					
						} else {		
						//outlet(2,"impact right");
						if(!agent[n].t) outlet(2,"hit","agent",n,3,xs,xloc,yloc,x,y);
						agent[n].xspeed = Math.abs(agent[n].xspeed);
						}
					} else {
						if(hit_top)	{
						//outlet(2,"impact top");
						if(!agent[n].t) outlet(2,"hit","agent",n,3,ys,xloc,yloc,x,y);
						agent[n].yspeed = 0 - agent[n].yspeed;
						} else {		
						//outlet(2,"impact bottom");
						if(!agent[n].t) outlet(2,"hit","agent",n,4,ys,xloc,yloc,x,y);
						agent[n].yspeed = Math.abs(agent[n].yspeed);
						}
					}		
				}				
			}
		}
	}

// bounce agents off walls
function bounce(n){
		var dx = agent[n].x + agent[n].xspeed;
		var dy = agent[n].y + agent[n].yspeed;
		var xs = Math.abs(agent[n].xspeed)/xmod;
		var ys = Math.abs(agent[n].yspeed)/ymod;
		var x = ftoi(agent[n].x);
		var y = ftoi((height-agent[n].y));
		var xloc = ftoi(agent[n].x)/width;
		var yloc = ftoi((height-agent[n].y))/height;
		// hit output takes format: route,type,id,face,speed,xloc,yloc,x,y
		// bounce x axis	
		if(dx > width){// right wall
			agent[n].xspeed = 0 - agent[n].xspeed;
			agent[n].x = width;
			if(!agent[n].t) outlet(2,"hit","agent",n,3,xs,xloc,yloc,x,y);
			if(toggle.wall) outlet(2,"hit","wall",0,3,xs,xloc,yloc,x,y);
			}
		else if(dx < 0){// left wall
			agent[n].xspeed = Math.abs(agent[n].xspeed);
			agent[n].x = 0;	
			if(!agent[n].t) outlet(2,"hit","agent",n,1,xs,xloc,yloc,x,y);
			if(toggle.wall) outlet(2,"hit","wall",0,1,xs,xloc,yloc,x,y);
			}		
		// bounce y axis	
		else if(dy > height){// bottom wall
			agent[n].yspeed = 0 - agent[n].yspeed;
			agent[n].y = height;		
			if(!agent[n].t) outlet(2,"hit","agent",n,4,ys,xloc,yloc,x,y);
			if(toggle.wall) outlet(2,"hit","wall",0,4,ys,xloc,yloc,x,y);
			}	
		else if(dy < 0){// top wall
			agent[n].yspeed = Math.abs(agent[n].yspeed);
			agent[n].y =0;		
			if(!agent[n].t) outlet(2,"hit","agent",n,2,ys,xloc,yloc,x,y);
			if(toggle.wall) outlet(2,"hit","wall",0,2,ys,xloc,yloc,x,y);
			}
	}
	
//convert float to int	
function ftoi(n){
	var n_int = Math.round(n);
	return n_int;	
	}
		
function toggle_collisions(x){
		toggle.collisions = x;	
	}
	
function toggle_friction(x){
		toggle.friction = x;	
	}

	
function toggle_wall(x){
		toggle.wall = x;	
	}
	
function toggle_onesound(){
	toggle.onesound = x;	
	}
	
function set_size(x){
		size = x;	
	}	
	
function set_friction(x){
		friction = x;	
	}	
		
	
// switch function
function toggle_switch(){
	if(agent[live_agent].t) agent[live_agent].t = 0;
	else agent[live_agent].t = 1;
	}