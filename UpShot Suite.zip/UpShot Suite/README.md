# upshot suite

upshot is a suite of audio effects, event generators, instruments and all kinds of utilities for quick and easy patching

installation

---> move the ‘Upshot Suite’ folder to Documents/Max8/Packages

Happy patching!

